package ID3;

public class Main {

	public static void main(String[] args) {
		ID3 id = new ID3();
		id.init();
	}
}
