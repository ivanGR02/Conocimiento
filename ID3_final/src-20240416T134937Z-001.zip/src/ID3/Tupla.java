package ID3;

public class Tupla {

	int si,total;//cuantos hay y cuantos si
	public Tupla(int total, int si){
		this.si=si;
		this.total=total;
	}
	public double entropia() {
		int no=total-si;
		return (si/total)*log2(si/total)-(no/total)*log2(no/total);
	}
	
	public static int log2(int N){
 
        // SI es log2(0) tenemos que poner que el resultado es 0 para que no pete.
		 int result;
		if(N==0) {
			result=0;
		}else {
			result= (int)(Math.log(N) / Math.log(2));
		}
        return result;
    }
	public void addCaso(boolean si) {
		total++;
		if(si) {
			this.si++;
		}
	}
}