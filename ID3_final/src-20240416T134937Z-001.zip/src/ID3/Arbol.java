package ID3;

import java.util.ArrayList;
import java.util.HashMap;

public class Arbol {
	HashMap<String,Rama> arbol;
	double min= Double.MAX_VALUE;
	String rasgo= "";
	ArrayList<Arbol> hijos;
	ArrayList<ArrayList<String>> datos;
	ArrayList<String> titulos;
	
	public void analizarRama() {
		arbol.forEach((k,v) ->{
			if(min>v.entropia()) {
				min=v.entropia();
				rasgo =k;
			}
		});
		System.out.println("La rama es "+rasgo);
		
	}
	public Arbol(ArrayList<ArrayList<String>> datos, ArrayList<String> titulos) {
		this.datos=datos;
		this.titulos=titulos;
		arbol = new HashMap<String,Rama>();
		for(int i=0;i<titulos.size()-2;i++) {// -2 ya que la columna de Jugar no tiene rama
			arbol.put(titulos.get(i),new Rama());
		}
		for(ArrayList<String> linea:datos) {
			for(int i=0;i<titulos.size()-2;i++) {
				boolean si;
				if(linea.get(titulos.size()-1).equals("si")) {
					si=true;
				}else {
					si=false;
				}
				arbol.get(titulos.get(i)).addCaracteristica(linea.get(i), si);
			}
		}
	}
	public void redistribucion() {// crear las sublistas por cada rama
		int posicion=0;// columna que eliminamos para 
		for(int i=0;i<titulos.size();i++) {
			if(titulos.get(i).equals(rasgo)) posicion=i;
		}
		HashMap<String,ArrayList<ArrayList<String>>> sublistas = new HashMap<String,ArrayList<ArrayList<String>>>();
		for(String rama:arbol.get(rasgo).clases()) {
			ArrayList<ArrayList<String>> subdatos = new ArrayList<ArrayList<String>>();
			for(int i=0;i<datos.size();i++) {
				//en la fila i, la columna con menos merito,si es igual a la rama
				if(datos.get(i).get(posicion).equals(rama)) {
					ArrayList<String> aux = datos.get(i);
					aux.remove(posicion);
					subdatos.add(aux);// eliminamos la columna con menos merito y la a�adimos a la subtabla
				}
			}
			sublistas.put(rasgo, subdatos);
		}
		ArrayList<String> nuevosTitulos=titulos;
		nuevosTitulos.remove(rasgo);
		ArrayList<Arbol> subArboles = new ArrayList<Arbol>();
		sublistas.forEach((nombre, tablas) -> {
				subArboles.add(new Arbol(tablas,nuevosTitulos));
		});
		this.hijos=subArboles;
	}
	public ArrayList<Arbol> getHijos(){
		return hijos;
	}
	public int RamaFinal() {
		String jugar= datos.get(0).get(titulos.size()-1);// miramos que el ultimo valor es un si o un no
		for(int i=0;i<datos.size();i++) {
			if(!datos.get(i).get(titulos.size()-1).equals(jugar))
				return -1;// hay que seguir explorando la rama
		}
		if(jugar.equals("si"))return 1;// rama positiva
		return 0;// rama negativa
	}
	
	public String toString() {
	    return toStringHelper(this, 0);
	}

	private String toStringHelper(Arbol nodo, int nivel) {
	    StringBuilder sb = new StringBuilder();

	    if (nodo.RamaFinal() == 1) {
	        sb.append("+"); // Rama positiva
	    } else if (nodo.RamaFinal() == 0) {
	        sb.append("-"); // Rama negativa
	    } else {
	        sb.append(nodo.rasgo).append(":").append("\n");
	        for (Arbol hijo : nodo.hijos) {
	            for (int i = 0; i <= nivel; i++) {
	                sb.append("\t"); // Agrega tabulaciones para la indentaci�n
	            }
	            sb.append("|-- ");
	            sb.append(toStringHelper(hijo, nivel + 1)); // Llamada recursiva para cada hijo
	        }
	    }

	    return sb.toString();
	}

}
